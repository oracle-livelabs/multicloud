variable "region" {
  type = string
}

variable "current_user_ocid" {
  type        = string
  description = "Automatically populated by OCI Resource Manager with the OCID of the user creating the stack."
}

variable "compartment_ocid" {
  type        = string
  description = "OCID of the learner child compartment created by the bootstrap stack; never the tenancy OCID."
}

variable "adb_vcn_ocid" {
  type        = string
  default     = ""
  description = "Existing VCN used to filter the subnet and NSG selectors in Resource Manager."
}

variable "adb_subnet_ocid" {
  type = string
}

variable "adb_nsg_ocid" {
  type = string
}

variable "display_name" {
  type    = string
  default = "lakehouse-v2"
}
variable "db_name" {
  type        = string
  default     = "LAKEV2"
  description = "Up to 14 letters/numbers, beginning with a letter."
}
variable "private_endpoint_label" {
  type    = string
  default = "lakev2adb"
}

variable "public_access_cidr" {
  type        = string
  description = "Public egress CIDR allowed to use the ADB public endpoint and Database Actions. Use a single workstation IP with /32 or a corporate/VPN CIDR; 0.0.0.0/0 is not allowed."

  validation {
    condition     = can(cidrnetmask(var.public_access_cidr)) && var.public_access_cidr != "0.0.0.0/0"
    error_message = "Provide a valid CIDR, such as 198.51.100.25/32 or a corporate/VPN CIDR. 0.0.0.0/0 is not permitted."
  }
}

variable "admin_password" {
  type        = string
  description = "Password for the Autonomous Database ADMIN account. It must be 12-30 characters, include uppercase, lowercase, and numeric characters, and cannot contain ADMIN, single quotes, or double quotes."
  sensitive   = true

  validation {
    condition = (
      length(var.admin_password) >= 12 &&
      length(var.admin_password) <= 30 &&
      can(regex("[A-Z]", var.admin_password)) &&
      can(regex("[a-z]", var.admin_password)) &&
      can(regex("[0-9]", var.admin_password)) &&
      !strcontains(lower(var.admin_password), "admin") &&
      !can(regex("[\\\"']", var.admin_password))
    )
    error_message = "ADMIN password must be 12-30 characters and include at least one uppercase letter, lowercase letter, and number. It cannot contain ADMIN (in any case), a single quote, or a double quote."
  }
}

variable "ecpu_count" {
  type    = number
  default = 2
}

variable "storage_tbs" {
  type    = number
  default = 1
}

resource "random_string" "unique_name" {
  length  = 5
  special = false
  lower   = true
  upper   = true
  numeric = false  # Ensures it starts with a letter
}
