output "autonomous_database_ocid" { value = oci_database_autonomous_database.lakehouse.id }
output "private_endpoint_ip" { value = oci_database_autonomous_database.lakehouse.private_endpoint_ip }
output "service_console_url" { value = oci_database_autonomous_database.lakehouse.service_console_url }
