output "autonomous_database_ocid" { value = oci_database_autonomous_database.lakehouse.id }
output "autonomous_database_display_name" { value = oci_database_autonomous_database.lakehouse.display_name }
output "autonomous_database_name" { value = oci_database_autonomous_database.lakehouse.db_name }
output "private_endpoint_label" { value = oci_database_autonomous_database.lakehouse.private_endpoint_label }
output "private_endpoint_ip" { value = oci_database_autonomous_database.lakehouse.private_endpoint_ip }
output "service_console_url" { value = oci_database_autonomous_database.lakehouse.service_console_url }
