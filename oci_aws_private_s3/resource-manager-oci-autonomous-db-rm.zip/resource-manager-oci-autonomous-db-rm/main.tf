resource "oci_database_autonomous_database" "lakehouse" {
  compartment_id              = var.compartment_ocid
  display_name                = "${var.display_name}${random_string.unique_name.result}"
  db_name                     = "${var.db_name}${random_string.unique_name.result}"
  db_workload                 = "DW"
  admin_password              = var.admin_password
  license_model               = "LICENSE_INCLUDED"
  compute_model               = "ECPU"
  compute_count               = var.ecpu_count
  data_storage_size_in_tbs    = var.storage_tbs
  is_mtls_connection_required = true

  subnet_id              = var.adb_subnet_ocid
  nsg_ids                = [var.adb_nsg_ocid]
  private_endpoint_label = var.private_endpoint_label

  # A non-empty ACL enables the additional public endpoint only for the
  # approved client CIDR.
  whitelisted_ips = [var.public_access_cidr]
}
