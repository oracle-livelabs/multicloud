data "oci_identity_user" "current_user" {
  user_id = var.current_user_ocid
}

locals {
  # OCI user names can include characters that aren't allowed in database or
  # private-endpoint names. Retain only letters and numbers for generated names.
  current_user_name = lower(join("", regexall("[0-9A-Za-z]", data.oci_identity_user.current_user.name)))
  random_suffix     = random_string.unique_name.result

  # Autonomous Database names are limited to 14 alphanumeric characters. Keep
  # the configured database prefix and random suffix, and use the remaining
  # characters for a recognizable, length-safe user-name segment.
  database_user_name_length = max(1, 14 - length(var.db_name) - length(local.random_suffix))
  database_user_name = upper(substr(
    local.current_user_name,
    max(0, length(local.current_user_name) - local.database_user_name_length),
    local.database_user_name_length
  ))
  database_name = "${substr(upper(var.db_name), 0, 14 - length(local.database_user_name) - length(local.random_suffix))}${local.database_user_name}${upper(local.random_suffix)}"
}

resource "oci_database_autonomous_database" "lakehouse" {
  compartment_id              = var.compartment_ocid
  display_name                = "${var.display_name}-${local.current_user_name}-${local.random_suffix}"
  db_name                     = local.database_name
  db_workload                 = "DW"
  admin_password              = var.admin_password
  license_model               = "LICENSE_INCLUDED"
  compute_model               = "ECPU"
  compute_count               = var.ecpu_count
  data_storage_size_in_tbs    = var.storage_tbs
  is_mtls_connection_required = true

  subnet_id              = var.adb_subnet_ocid
  nsg_ids                = [var.adb_nsg_ocid]
  private_endpoint_label = "${var.private_endpoint_label}${local.current_user_name}${lower(local.random_suffix)}"

  # A non-empty ACL enables the additional public endpoint only for the
  # approved client CIDR.
  whitelisted_ips = [var.public_access_cidr]
}
