# Autonomous AI Database Resource Manager stack

Package this folder's `.tf` files and `schema.yaml` at the root of a ZIP archive and upload it as an OCI Resource Manager stack with **Working directory** blank. A ready-made archive is supplied at the top of the V2 package. The schema is intentional: it makes the Create stack wizard display the required variables.

Pass the subnet and NSG OCIDs emitted by the OCI network stack. Mark `admin_password` **Sensitive** in the Resource Manager Variables page before running a job. This stack creates an Autonomous AI Database Serverless data warehouse (`DW`) with an ECPU compute model and a private endpoint. It also enables the additional ADB public endpoint only for `public_access_cidr`; enter the same workstation public egress `/32` or corporate/VPN CIDR used for `admin_client_cidr` in the companion network stack. It intentionally does not accept or store AWS access keys or other cloud credentials. The learner enters their AWS key pair manually in Database Actions to create the S3 credential and external table.

After it is available, the learner runs `ALTER DATABASE PROPERTY SET ROUTE_OUTBOUND_CONNECTIONS = 'ENFORCE_PRIVATE_ENDPOINT';` as `ADMIN` in their isolated ADB. That database property is purposely a post-provisioning SQL action; it is what forces `DBMS_CLOUD` network egress through the private endpoint.
