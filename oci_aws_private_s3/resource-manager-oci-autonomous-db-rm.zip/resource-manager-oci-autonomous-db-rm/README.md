# Autonomous AI Database Resource Manager stack

Package this folder's `.tf` files and `schema.yaml` at the root of a ZIP archive and upload it as an OCI Resource Manager stack with **Working directory** blank. A ready-made archive is supplied at the top of the V2 package. The schema is intentional: it makes the Create stack wizard display the required variables.

Select the subnet and NSG created by the OCI network stack in the Resource Manager drop-down controls. Mark `admin_password` **Sensitive** in the Resource Manager Variables page before running a job. This stack creates an Autonomous AI Database Serverless data warehouse (`DW`) with an ECPU compute model and a private endpoint. It also enables the additional ADB public endpoint only for `public_access_cidr`; enter the same workstation public egress `/32` or corporate/VPN CIDR used for `admin_client_cidr` in the companion network stack. It intentionally does not accept or store AWS access keys or other cloud credentials. The learner enters their AWS key pair manually in Database Actions to create the S3 credential and external table.

## Values to enter in Resource Manager

### Allowed public client CIDR

Use the public egress address of the computer from which you will open Database Actions. A single computer address must use the `/32` suffix.

- **macOS:** Open Terminal and run `curl ifconfig.me`. If it returns `198.51.100.25`, enter `198.51.100.25/32`.
- **Windows:** Open Command Prompt, run `ipconfig`, and find the **IPv4 Address** for the active network adapter. Append `/32`; for example, enter `198.51.100.25/32`.

If `ipconfig` shows a private address such as `10.x.x.x` or `192.168.x.x`, your network is using NAT, a proxy, or a VPN. Obtain the approved public egress CIDR from the network administrator instead. Do not use `0.0.0.0/0`.

### ADMIN password

The stack checks the following Autonomous Database password requirements before it creates the database:

- 12 through 30 characters (30 is the maximum).
- At least one uppercase letter, lowercase letter, and number.
- Must not contain the database username `ADMIN`, in any letter case.
- Must not contain a single quotation mark (`'`) or double quotation mark (`"`).

For example, `Lakehouse2026Lab` meets these rules. Keep this password private; it is used to sign in to Database Actions as `ADMIN`.

OCI Resource Manager automatically supplies the stack creator's `current_user_ocid`. The stack reads that user's name and appends it, plus the existing random suffix, to the database display name and private endpoint label. The database name also contains a length-safe user-name segment and the random suffix because Autonomous Database names are limited to 14 alphanumeric characters. The user running the stack must be authorized to read their OCI user record.

After it is available, the learner runs `ALTER DATABASE PROPERTY SET ROUTE_OUTBOUND_CONNECTIONS = 'ENFORCE_PRIVATE_ENDPOINT';` as `ADMIN` in their isolated ADB. That database property is purposely a post-provisioning SQL action; it is what forces `DBMS_CLOUD` network egress through the private endpoint.
