resource "oci_core_vcn" "lakehouse" {
  compartment_id = var.compartment_ocid
  display_name   = "${var.name_prefix}-vcn"
  cidr_blocks    = [var.vcn_cidr]
  dns_label      = "lakev2"
}

# OCI creates the VCN resolver asynchronously. This data source waits for the
# association to be available and exposes the resolver OCID to Terraform.
data "oci_core_vcn_dns_resolver_association" "lakehouse" {
  vcn_id = oci_core_vcn.lakehouse.id
}

resource "oci_core_drg" "lakehouse" {
  compartment_id = var.compartment_ocid
  display_name   = "${var.name_prefix}-drg"
}

resource "oci_core_drg_attachment" "vcn" {
  drg_id       = oci_core_drg.lakehouse.id
  display_name = "${var.name_prefix}-vcn-attachment"

  network_details {
    id   = oci_core_vcn.lakehouse.id
    type = "VCN"
  }
}

resource "oci_core_route_table" "private" {
  compartment_id = var.compartment_ocid
  display_name   = "${var.name_prefix}-private-rt"
  vcn_id         = oci_core_vcn.lakehouse.id

  route_rules {
    destination       = var.aws_vpc_cidr
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_drg.lakehouse.id
  }
}

resource "oci_core_subnet" "adb" {
  compartment_id             = var.compartment_ocid
  display_name               = "${var.name_prefix}-adb-private-subnet"
  vcn_id                     = oci_core_vcn.lakehouse.id
  cidr_block                 = var.adb_subnet_cidr
  dns_label                  = "adb"
  route_table_id             = oci_core_route_table.private.id
  prohibit_public_ip_on_vnic = true
}

resource "oci_core_subnet" "dns" {
  compartment_id             = var.compartment_ocid
  display_name               = "${var.name_prefix}-dns-private-subnet"
  vcn_id                     = oci_core_vcn.lakehouse.id
  cidr_block                 = var.dns_subnet_cidr
  dns_label                  = "dns"
  route_table_id             = oci_core_route_table.private.id
  prohibit_public_ip_on_vnic = true
}

resource "oci_core_network_security_group" "adb" {
  compartment_id = var.compartment_ocid
  display_name   = "${var.name_prefix}-adb-nsg"
  vcn_id         = oci_core_vcn.lakehouse.id
}

resource "oci_core_network_security_group_security_rule" "adb_client_ingress" {
  network_security_group_id = oci_core_network_security_group.adb.id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = var.admin_client_cidr
  source_type               = "CIDR_BLOCK"
  tcp_options {
    destination_port_range {
      min = 1522
      max = 1522
    }
  }
}

# Database Actions and ORDS use HTTPS. This mirrors the ADB public-endpoint
# ACL so that only the approved administrator/workstation CIDR can reach the
# browser-based database tools.
resource "oci_core_network_security_group_security_rule" "adb_database_actions_ingress" {
  network_security_group_id = oci_core_network_security_group.adb.id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = var.admin_client_cidr
  source_type               = "CIDR_BLOCK"
  tcp_options {
    destination_port_range {
      min = 443
      max = 443
    }
  }
}

resource "oci_core_network_security_group_security_rule" "adb_to_s3" {
  network_security_group_id = oci_core_network_security_group.adb.id
  direction                 = "EGRESS"
  protocol                  = "6"
  destination               = var.aws_vpc_cidr
  destination_type          = "CIDR_BLOCK"
  tcp_options {
    destination_port_range {
      min = 443
      max = 443
    }
  }
}

resource "oci_core_network_security_group" "dns" {
  compartment_id = var.compartment_ocid
  display_name   = "${var.name_prefix}-dns-forwarder-nsg"
  vcn_id         = oci_core_vcn.lakehouse.id
}

resource "oci_core_network_security_group_security_rule" "dns_udp_to_aws" {
  network_security_group_id = oci_core_network_security_group.dns.id
  direction                 = "EGRESS"
  protocol                  = "17"
  destination               = var.aws_vpc_cidr
  destination_type          = "CIDR_BLOCK"
  udp_options {
    destination_port_range {
      min = 53
      max = 53
    }
  }
}

resource "oci_core_network_security_group_security_rule" "dns_tcp_to_aws" {
  network_security_group_id = oci_core_network_security_group.dns.id
  direction                 = "EGRESS"
  protocol                  = "6"
  destination               = var.aws_vpc_cidr
  destination_type          = "CIDR_BLOCK"
  tcp_options {
    destination_port_range {
      min = 53
      max = 53
    }
  }
}

resource "oci_dns_resolver_endpoint" "forwarder" {
  resolver_id = data.oci_core_vcn_dns_resolver_association.lakehouse.dns_resolver_id
  # Resolver endpoint names accept letters, digits, and underscores only.
  name               = "aws_forwarder"
  is_forwarding      = true
  is_listening       = false
  # Let OCI allocate an available private IP address in the DNS subnet.  This
  # avoids a failed endpoint when a manually selected address is unavailable.
  subnet_id          = oci_core_subnet.dns.id
  nsg_ids            = [oci_core_network_security_group.dns.id]
  scope              = "PRIVATE"
}

resource "oci_dns_resolver" "vcn_resolver" {
  resolver_id = data.oci_core_vcn_dns_resolver_association.lakehouse.dns_resolver_id
  scope       = "PRIVATE"
  rules {
    action                 = "FORWARD"
    destination_addresses  = [var.aws_resolver_inbound_ip]
    qname_cover_conditions = [var.s3_dns_domain]
    source_endpoint_name   = oci_dns_resolver_endpoint.forwarder.name
  }
}
