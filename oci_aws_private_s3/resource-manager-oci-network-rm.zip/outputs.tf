output "vcn_ocid" { value = oci_core_vcn.lakehouse.id }
output "drg_ocid" { value = oci_core_drg.lakehouse.id }
output "adb_subnet_ocid" { value = oci_core_subnet.adb.id }
output "adb_nsg_ocid" { value = oci_core_network_security_group.adb.id }
output "dns_forwarding_endpoint_ip" { value = oci_dns_resolver_endpoint.forwarder.forwarding_address }
output "next_step" { value = "Create the OCI Interconnect for AWS virtual circuit using this DRG OCID, then deploy the Autonomous Database stack." }
