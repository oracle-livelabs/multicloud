# OCI network Resource Manager stack

Package this folder's `.tf` files and `schema.yaml` at the root of a ZIP archive and upload it as an OCI Resource Manager stack with **Working directory** blank. A ready-made archive is supplied at the top of the V2 package. The schema is intentional: it makes the Create stack wizard display the required variables.

The stack creates a VCN, DRG, VCN attachment, private subnets for Autonomous AI Database and DNS forwarding, private routes to the AWS VPC, NSGs, an OCI DNS forwarding endpoint, and an OCI resolver forwarding rule for the regional S3 hostname. The ADB NSG permits the restricted `admin_client_cidr` on TCP 1522 for database clients and TCP 443 for Database Actions; use the same CIDR as `public_access_cidr` in the ADB stack.

The current archive has been syntax- and provider-schema-validated with Terraform 1.5.7 and the OCI provider. Do not reuse an earlier downloaded archive.

Before applying, obtain one Route 53 inbound resolver IP address from the AWS stack and enter it for `aws_resolver_inbound_ip`. OCI resolver rules support one destination address per rule; use either of AWS's two inbound IP addresses.

This stack does not create an Oracle Interconnect virtual circuit. The circuit needs an OCI-generated activation key and AWS acceptance, so it remains the manual learner interconnect workflow in Sections 3 and 4 of the learner guide.
