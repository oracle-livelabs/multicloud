variable "region" {
  type = string
}

variable "compartment_ocid" {
  type = string
}

variable "name_prefix" {
  type    = string
  default = "lakehouse-v2"
}

variable "vcn_cidr" {
  type    = string
  default = "10.10.0.0/16"
}

variable "adb_subnet_cidr" {
  type    = string
  default = "10.10.30.0/24"
}

variable "dns_subnet_cidr" {
  type    = string
  default = "10.10.40.0/24"
}

variable "aws_vpc_cidr" {
  type    = string
  default = "10.20.0.0/16"
}
variable "aws_resolver_inbound_ip" {
  type        = string
  description = "One Route 53 inbound resolver IP from the AWS stack output/details page."
}
variable "s3_dns_domain" {
  type        = string
  description = "AWS regional S3 DNS suffix, for example s3.us-east-1.amazonaws.com."
  default     = "s3.us-east-1.amazonaws.com"
}
variable "admin_client_cidr" {
  type        = string
  description = "CIDR allowed to connect to the Autonomous Database listener. Use a corporate/VPN CIDR, not 0.0.0.0/0."
}
